﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public string entry;
        public string result;
        public string value;
        public float[] numbers;
        public string[] operators;
        public int num_ct = 0;
        public int opr_ct = 0;
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = Environment.NewLine + Environment.NewLine + Environment.NewLine + "-------------------" + Environment.NewLine + Environment.NewLine + Environment.NewLine;
            entry = "";
            result = "";
            value = "";
            numbers = new float[1000];
            operators = new string[1000];
            num_ct = 0;
            opr_ct = 0;

    }

        private void display_update()
        {
            textBox1.Text =  Environment.NewLine + entry + Environment.NewLine + Environment.NewLine + "-------------------" + Environment.NewLine + result + Environment.NewLine + Environment.NewLine;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {
            entry = "";
            result = "";
            numbers = new float[1000];
            operators = new string[1000];
            display_update();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            //this is the +/- button
            entry = "-" + entry;
            value = "-" + value;
            display_update();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            entry += "*";

            operators[opr_ct] = "*";
            opr_ct++;

            numbers[num_ct] = float.Parse(value); //prevents the user from entering an operation without entering a number
            num_ct++;
            value = "";

            display_update();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            entry += "/";

            operators[opr_ct] = "/";
            opr_ct++;

            numbers[num_ct] = float.Parse(value); //prevents the user from entering an operation without entering a number
            num_ct++;
            value = "";

            display_update();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            entry += "%";

            operators[opr_ct] = "%";
            opr_ct++;

            numbers[num_ct] = float.Parse(value); //prevents the user from entering an operation without entering a number
            num_ct++;
            value = "";

            display_update();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            entry += "+";

            operators[opr_ct] = "+";
            opr_ct++;

            numbers[num_ct] = float.Parse(value); //prevents the user from entering an operation without entering a number
            num_ct++;
            value = "";

            display_update();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            entry += "-";

            operators[opr_ct] = "-";
            opr_ct++;

            numbers[num_ct] = float.Parse(value); //prevents the user from entering an operation without entering a number
            num_ct++;
            value = "";

            display_update();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            entry += ".";
            value += ".";

            display_update();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            entry += "0";
            value += "0";

            display_update();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            entry += "1";
            value += "1";

            display_update();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            entry += "2";
            value += "2";

            display_update();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            entry += "3";
            value += "3";

            display_update();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            entry += "4";
            value += "4";

            display_update();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            entry += "5";
            value += "5";

            display_update();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            entry += "6";
            value += "6";

            display_update();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            entry += "7";
            value += "7";

            display_update();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            entry += "8";
            value += "8";

            display_update();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            entry += "9";
            value += "9";

            display_update();
        }

        public float Solver(float first, string oper, float second)
        {
            float third = 0;

            if(oper == "+")
            {
                third = first + second;
            }
            else if(oper == "-")
            {
                third = first - second;
            }
            else if(oper == "*")
            {
                third = first * second;
            }
            else if(oper == "/")
            {
                third = first / second;
            }
            else if(oper == "%")
            {
                third = first % second;
            }

            return third;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            //perform equation

            numbers[num_ct] = float.Parse(value); //prevents the user from entering an operation without entering a number
            num_ct++;
            value = "";

            for (int x = 0; x < opr_ct; x++)
            {
                if (operators[x] == "*")
                {
                    numbers[x] = Solver(numbers[x], operators[x], numbers[x + 1]);
                    for (int y = x + 1; y < opr_ct; y++)
                    {
                        numbers[y] = numbers[y + 1];
                        operators[y - 1] = operators[y];
                    }
                }
            }
            for (int x = 0; x < opr_ct; x++)
            {
                if (operators[x] == "/")
                {
                    numbers[x] = Solver(numbers[x], operators[x], numbers[x + 1]);
                    for (int y = x + 1; y < opr_ct; y++)
                    {
                        numbers[y] = numbers[y + 1];
                        operators[y - 1] = operators[y];
                    }
                }
            }
            for (int x = 0; x < opr_ct; x++)
            {
                if (operators[x] == "%")
                {
                    numbers[x] = Solver(numbers[x], operators[x], numbers[x + 1]);
                    for (int y = x + 1; y < opr_ct; y++)
                    {
                        numbers[y] = numbers[y + 1];
                        operators[y - 1] = operators[y];
                    }
                }
            }
            for (int x = 0; x < opr_ct; x++)
            {
                if (operators[x] == "+")
                {
                    numbers[x] = Solver(numbers[x], operators[x], numbers[x + 1]);
                    for (int y = x + 1; y < opr_ct; y++)
                    {
                        numbers[y] = numbers[y + 1];
                        operators[y - 1] = operators[y];
                    }
                }
            }
            for (int x = 0; x < opr_ct; x++)
            {
                if (operators[x] == "-")
                {
                    numbers[x] = Solver(numbers[x], operators[x], numbers[x + 1]);
                    for (int y = x + 1; y < opr_ct; y++)
                    {
                        numbers[y] = numbers[y + 1];
                        operators[y - 1] = operators[y];
                    }
                }
            }

            result = Convert.ToString(numbers[0]);

            display_update();
        }
    }
}
